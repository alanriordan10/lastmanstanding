import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { useState, useMemo } from 'react';
import api from '../api';
import type { Competition, Participant } from '../types';

interface SurvivorRow {
  userId: number;
  username: string;
  status: 'ACTIVE' | 'ELIMINATED' | 'WINNER';
  eliminatedWeek: number | null;
  picks: Record<number, { teamShortName: string; outcome: string; source: string } | null>;
}

interface GameweekMeta {
  id: number;
  weekNumber: number;
  status: string;
}

export default function SurvivorTablePage() {
  const { id } = useParams<{ id: string }>();
  const compId = Number(id);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'ELIMINATED' | 'WINNER'>('ALL');

  const { data: comp } = useQuery<Competition>({
    queryKey: ['competition', compId],
    queryFn: () => api.get(`/competitions/${compId}`).then((r) => r.data),
  });

  const { data: tableData, isLoading } = useQuery<{ gameweeks: GameweekMeta[]; rows: SurvivorRow[] }>({
    queryKey: ['survivor-table', compId],
    queryFn: () => api.get(`/competitions/${compId}/survivor-table`).then((r) => r.data),
    refetchInterval: 60_000,
  });

  const gameweeks = tableData?.gameweeks ?? [];
  const rows = tableData?.rows ?? [];

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      const matchSearch = !search || r.username.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'ALL' || r.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [rows, search, statusFilter]);

  const counts = {
    ALL: rows.length,
    ACTIVE: rows.filter((r) => r.status === 'ACTIVE').length,
    ELIMINATED: rows.filter((r) => r.status === 'ELIMINATED').length,
    WINNER: rows.filter((r) => r.status === 'WINNER').length,
  };

  // Sort: winner first, then active (most gameweeks survived last), then eliminated (latest GW first)
  const sorted = [...filtered].sort((a, b) => {
    const rank = (r: SurvivorRow) => r.status === 'WINNER' ? 0 : r.status === 'ACTIVE' ? 1 : 2;
    if (rank(a) !== rank(b)) return rank(a) - rank(b);
    if (a.status === 'ELIMINATED' && b.status === 'ELIMINATED') {
      return (b.eliminatedWeek ?? 0) - (a.eliminatedWeek ?? 0);
    }
    return a.username.localeCompare(b.username);
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <Link to={`/competitions/${compId}`} className="text-sm text-gray-400 hover:text-white">
            ← Back to competition
          </Link>
          <h1 className="mt-2 text-2xl font-bold">Survivor Table</h1>
          {comp && <p className="text-sm text-gray-400 mt-1">{comp.name}</p>}
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-brand-400">{counts.ACTIVE}</p>
          <p className="text-xs text-gray-400">still active</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          placeholder="Search participant…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="input-field w-full sm:max-w-xs text-sm"
        />
        <div className="inline-flex rounded-lg bg-surface-700 p-1 flex-wrap gap-1">
          {(['ALL', 'ACTIVE', 'ELIMINATED', 'WINNER'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                statusFilter === s ? 'bg-brand-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              {s} ({counts[s]})
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
        </div>
      ) : !gameweeks.length ? (
        <div className="card text-center py-16">
          <p className="text-gray-400">No data available yet</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-gray-700/50">
          <table className="w-full text-sm min-w-max">
            <thead>
              <tr className="border-b border-gray-700/50 bg-surface-800/80">
                <th className="text-left py-3 px-4 font-semibold text-gray-300 sticky left-0 bg-surface-800/95 z-10 min-w-[140px]">
                  Participant
                </th>
                {gameweeks.map((gw) => (
                  <th key={gw.id} className="py-3 px-3 font-semibold text-gray-300 text-center min-w-[80px]">
                    <div>GW{gw.weekNumber}</div>
                    <div className={`text-[10px] font-normal mt-0.5 ${
                      gw.status === 'COMPLETED' ? 'text-green-500' :
                      gw.status === 'IN_PROGRESS' ? 'text-yellow-400' :
                      gw.status === 'LOCKED' ? 'text-blue-400' : 'text-gray-500'
                    }`}>{gw.status}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700/30">
              {sorted.length === 0 ? (
                <tr>
                  <td colSpan={gameweeks.length + 1} className="py-12 text-center text-gray-400">
                    No participants found
                  </td>
                </tr>
              ) : sorted.map((row) => (
                <tr
                  key={row.userId}
                  className={`transition-colors ${
                    row.status === 'WINNER' ? 'bg-yellow-600/10 hover:bg-yellow-600/15' :
                    row.status === 'ACTIVE' ? 'hover:bg-surface-700/40' :
                    'opacity-60 hover:opacity-80 hover:bg-surface-700/30'
                  }`}
                >
                  {/* Name + status */}
                  <td className="py-3 px-4 sticky left-0 bg-surface-900/95 z-10">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-200 truncate max-w-[110px]">{row.username}</span>
                      {row.status === 'WINNER' && <span className="text-sm shrink-0">🏆</span>}
                      {row.status === 'ELIMINATED' && (
                        <span className="text-[10px] text-red-400 shrink-0">GW{row.eliminatedWeek}</span>
                      )}
                    </div>
                  </td>
                  {/* One cell per gameweek */}
                  {gameweeks.map((gw) => {
                    const pick = row.picks[gw.weekNumber];
                    if (!pick) {
                      // No pick — were they eliminated before this week?
                      const eliminatedBefore = row.eliminatedWeek !== null && gw.weekNumber > row.eliminatedWeek;
                      return (
                        <td key={gw.id} className="py-3 px-3 text-center">
                          {eliminatedBefore ? (
                            <span className="text-gray-700 text-base">—</span>
                          ) : gw.status === 'UPCOMING' ? (
                            <span className="text-gray-600 text-xs">·</span>
                          ) : (
                            <span className="text-gray-500 text-xs italic">no pick</span>
                          )}
                        </td>
                      );
                    }
                    return (
                      <td key={gw.id} className="py-3 px-3 text-center">
                        <div className="flex flex-col items-center gap-1">
                          <span className={`text-xs font-semibold px-2 py-0.5 rounded ${cellClass(pick.outcome)}`}>
                            {pick.teamShortName}
                          </span>
                          {pick.outcome !== 'PENDING' && (
                            <span className="text-[10px]">{outcomeIcon(pick.outcome)}</span>
                          )}
                          {pick.source === 'AUTO' && (
                            <span className="text-[9px] text-gray-500 italic">auto</span>
                          )}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-xs text-gray-400">
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-6 h-5 rounded bg-green-600/20 text-green-400 text-center leading-5 font-semibold text-[10px]">MCY</span>
          Advanced
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-6 h-5 rounded bg-red-600/20 text-red-400 text-center leading-5 font-semibold text-[10px]">ARS</span>
          Eliminated
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-6 h-5 rounded bg-yellow-600/20 text-yellow-400 text-center leading-5 font-semibold text-[10px]">CHE</span>
          Postponed / Bye
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block w-6 h-5 rounded bg-gray-600/20 text-gray-400 text-center leading-5 font-semibold text-[10px]">LIV</span>
          Pending
        </span>
      </div>
    </div>
  );
}

function cellClass(outcome: string): string {
  switch (outcome) {
    case 'ADVANCE': return 'bg-green-600/25 text-green-300';
    case 'ELIMINATED': return 'bg-red-600/25 text-red-300';
    case 'POSTPONED_ADVANCE': return 'bg-yellow-600/25 text-yellow-300';
    case 'PENDING': return 'bg-surface-700 text-gray-400';
    default: return 'bg-surface-700 text-gray-400';
  }
}

function outcomeIcon(outcome: string): string {
  switch (outcome) {
    case 'ADVANCE': return '✓';
    case 'ELIMINATED': return '✗';
    case 'POSTPONED_ADVANCE': return '↷';
    default: return '';
  }
}
