package com.lastmanstanding.repository;

import com.lastmanstanding.entity.User;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    Optional<User> findByUsername(String username);

    boolean existsByEmail(String email);

    boolean existsByUsername(String username);

    List<User> findAllByOrderByUsernameAsc();

    List<User> findByUsernameLike(String pattern);

    Optional<User> findByOauthProviderAndOauthProviderId(String provider, String providerId);
}
