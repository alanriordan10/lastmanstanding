package com.lastmanstanding.repository;

import com.lastmanstanding.entity.CompetitionParticipant;
import com.lastmanstanding.entity.ParticipantStatus;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompetitionParticipantRepository extends JpaRepository<CompetitionParticipant, Long> {

    Optional<CompetitionParticipant> findByCompetitionIdAndUserId(Long competitionId, Long userId);

    List<CompetitionParticipant> findByCompetitionId(Long competitionId);

    List<CompetitionParticipant> findByCompetitionIdAndStatus(Long competitionId, ParticipantStatus status);

    boolean existsByCompetitionIdAndUserId(Long competitionId, Long userId);

    long countByCompetitionIdAndStatus(Long competitionId, ParticipantStatus status);

    List<CompetitionParticipant> findByUserId(Long userId);

    void deleteByCompetitionIdAndUserId(Long competitionId, Long userId);

    void deleteByUserId(Long userId);

    void deleteByCompetitionId(Long competitionId);
}
