package com.lastmanstanding.repository;

import com.lastmanstanding.entity.Pick;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PickRepository extends JpaRepository<Pick, Long> {

    Optional<Pick> findByCompetitionIdAndUserIdAndGameweekId(Long competitionId, Long userId, Long gameweekId);

    List<Pick> findByCompetitionIdAndUserId(Long competitionId, Long userId);

    List<Pick> findByCompetitionIdAndGameweekId(Long competitionId, Long gameweekId);

    boolean existsByCompetitionIdAndUserIdAndTeamId(Long competitionId, Long userId, Long teamId);

    @Query("SELECT p.team.id FROM Pick p WHERE p.competition.id = :competitionId AND p.user.id = :userId")
    List<Long> findUsedTeamIds(@Param("competitionId") Long competitionId, @Param("userId") Long userId);

    List<Pick> findByCompetitionId(Long competitionId);

    List<Pick> findByUserId(Long userId);

    void deleteByCompetitionIdAndUserId(Long competitionId, Long userId);

    void deleteByUserId(Long userId);

    void deleteByCompetitionId(Long competitionId);
}
