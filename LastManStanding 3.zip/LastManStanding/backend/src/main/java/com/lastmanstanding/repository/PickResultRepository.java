package com.lastmanstanding.repository;

import com.lastmanstanding.entity.PickResult;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PickResultRepository extends JpaRepository<PickResult, Long> {

    Optional<PickResult> findByPickId(Long pickId);

    List<PickResult> findByPickIdIn(List<Long> pickIds);

    void deleteByPickIdIn(List<Long> pickIds);

    @Query("SELECT pr FROM PickResult pr JOIN pr.pick p WHERE p.competition.id = :competitionId AND p.gameweek.id = :gameweekId")
    List<PickResult> findByCompetitionIdAndGameweekId(@Param("competitionId") Long competitionId, @Param("gameweekId") Long gameweekId);

    @Query("DELETE FROM PickResult pr WHERE pr.pick.id IN (SELECT p.id FROM Pick p WHERE p.competition.id = :competitionId AND p.user.id = :userId)")
    @org.springframework.data.jpa.repository.Modifying
    void deleteByCompetitionIdAndUserId(@Param("competitionId") Long competitionId, @Param("userId") Long userId);

    @Query("DELETE FROM PickResult pr WHERE pr.pick.id IN (SELECT p.id FROM Pick p WHERE p.competition.id = :competitionId)")
    @org.springframework.data.jpa.repository.Modifying
    void deleteByCompetitionId(@Param("competitionId") Long competitionId);
}
