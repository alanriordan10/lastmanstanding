package com.lastmanstanding.repository;

import com.lastmanstanding.entity.Gameweek;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface GameweekRepository extends JpaRepository<Gameweek, Long> {

    List<Gameweek> findByCompetitionIdOrderByWeekNumberAsc(Long competitionId);

    Optional<Gameweek> findByCompetitionIdAndWeekNumber(Long competitionId, Integer weekNumber);

    @Query("SELECT g FROM Gameweek g WHERE g.competition.id = :competitionId AND g.status <> com.lastmanstanding.entity.GameweekStatus.COMPLETED ORDER BY g.weekNumber ASC LIMIT 1")
    Optional<Gameweek> findCurrentGameweek(@Param("competitionId") Long competitionId);

    @Query("SELECT g FROM Gameweek g WHERE g.competition.id = :competitionId AND g.status IN (com.lastmanstanding.entity.GameweekStatus.UPCOMING, com.lastmanstanding.entity.GameweekStatus.LOCKED, com.lastmanstanding.entity.GameweekStatus.IN_PROGRESS) ORDER BY g.weekNumber ASC LIMIT :limit")
    List<Gameweek> findNextUpcomingGameweeks(@Param("competitionId") Long competitionId, @Param("limit") int limit);
}
