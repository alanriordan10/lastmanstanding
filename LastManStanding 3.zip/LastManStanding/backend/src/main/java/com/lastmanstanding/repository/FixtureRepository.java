package com.lastmanstanding.repository;

import com.lastmanstanding.entity.Fixture;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FixtureRepository extends JpaRepository<Fixture, Long> {

    List<Fixture> findByGameweekId(Long gameweekId);

    List<Fixture> findByGameweekIdIn(List<Long> gameweekIds);

    Optional<Fixture> findByExternalFixtureId(String externalFixtureId);

    Optional<Fixture> findByExternalFixtureIdAndGameweekId(String externalFixtureId, Long gameweekId);

    void deleteByGameweekId(Long gameweekId);
}
