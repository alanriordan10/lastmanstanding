package com.lastmanstanding.service;

import com.lastmanstanding.entity.*;
import com.lastmanstanding.provider.FixtureProvider;
import com.lastmanstanding.provider.FixtureProvider.ProviderFixture;
import com.lastmanstanding.provider.FixtureProvider.ProviderTeam;
import com.lastmanstanding.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service that syncs teams, fixtures, and results from a FixtureProvider into the DB.
 * Only updates imported fields; admin overrides are never touched.
 */
@Service
public class FixtureSyncService {

    private static final Logger log = LoggerFactory.getLogger(FixtureSyncService.class);

    private final FixtureProvider fixtureProvider;
    private final TeamRepository teamRepository;
    private final FixtureRepository fixtureRepository;
    private final GameweekRepository gameweekRepository;
    private final CompetitionRepository competitionRepository;

    public FixtureSyncService(FixtureProvider fixtureProvider,
                              TeamRepository teamRepository,
                              FixtureRepository fixtureRepository,
                              GameweekRepository gameweekRepository,
                              CompetitionRepository competitionRepository) {
        this.fixtureProvider = fixtureProvider;
        this.teamRepository = teamRepository;
        this.fixtureRepository = fixtureRepository;
        this.gameweekRepository = gameweekRepository;
        this.competitionRepository = competitionRepository;
    }

    @Transactional
    public void syncTeams() {
        List<ProviderTeam> providerTeams = fixtureProvider.fetchTeams();
        for (ProviderTeam pt : providerTeams) {
            Team team = teamRepository.findByExternalTeamId(pt.externalId())
                    .orElse(new Team(pt.name(), pt.shortName(), pt.externalId(), pt.logoUrl()));
            team.setName(pt.name());
            team.setShortName(pt.shortName());
            if (pt.logoUrl() != null) team.setLogoUrl(pt.logoUrl());
            teamRepository.save(team);
        }
        log.info("Synced {} teams", providerTeams.size());
    }

    @Transactional
    public void syncFixturesAndResults() {
        LocalDate from = LocalDate.now().minusDays(30);
        LocalDate to = LocalDate.now().plusDays(60);

        // Sync fixtures
        List<ProviderFixture> fixtures = fixtureProvider.fetchFixtures(from, to);
        upsertFixtures(fixtures);

        // Sync results
        List<ProviderFixture> results = fixtureProvider.fetchResults(from, to);
        upsertFixtures(results);

        log.info("Synced {} fixtures and {} results", fixtures.size(), results.size());
    }

    @Transactional
    public void fullSync() {
        syncTeams();
        syncFixturesAndResults();
    }

    /**
     * Immediately populate fixtures for a single newly-created competition.
     * Called right after competition creation so users don't have to wait for the scheduler.
     */
    @Transactional
    public int syncForCompetition(Competition competition) {
        LocalDate compStart = competition.getStartDate() != null
                ? competition.getStartDate()
                : LocalDate.now();
        // Look back 7 days purely to detect which PL weeks have already started.
        // We don't include those past fixtures in the competition — they're only
        // used to identify week numbers that should be skipped.
        LocalDate from = compStart.minusDays(7);
        LocalDate to   = compStart.plusDays(120);

        log.info("syncForCompetition: competition='{}' provider={} fetchRange={} → {} (compStart={})",
                competition.getName(), fixtureProvider.getClass().getSimpleName(), from, to, compStart);

        // Always sync teams first — required so team FK lookups succeed
        // Also evict the fixture cache so we get fresh data with correct statuses —
        // stale cached data may show fixtures as SCHEDULED when they've already kicked off
        fixtureProvider.evictAll();
        syncTeams();

        List<ProviderFixture> fixtures = fixtureProvider.fetchFixtures(from, to);
        List<ProviderFixture> results  = fixtureProvider.fetchResults(from, to);

        log.info("syncForCompetition: provider returned {} fixtures, {} results",
                fixtures.size(), results.size());

        // Merge — results override fixtures for the same externalId
        java.util.Map<String, ProviderFixture> merged = new java.util.LinkedHashMap<>();
        fixtures.forEach(f -> merged.put(f.externalFixtureId(), f));
        results.forEach(r -> merged.put(r.externalFixtureId(), r));

        // Determine which PL weeks have already started (any fixture kicked off before now).
        // Check against the FULL merged list — not the date-filtered one — so that a week
        // whose first game was on Apr 21 is correctly detected even if the competition
        // start date is Apr 22 (which would otherwise filter out the Apr 21 fixture).
        java.time.LocalDateTime now = java.time.LocalDateTime.now(java.time.ZoneOffset.UTC);
        log.info("syncForCompetition: current UTC time = {}", now);

        java.util.Set<Integer> startedWeeks = merged.values().stream()
                .filter(pf -> pf.kickoffAt().isBefore(now))
                .map(ProviderFixture::weekNumber)
                .collect(java.util.stream.Collectors.toSet());

        // Log earliest kickoff per week so we can verify the decision
        merged.values().stream()
                .collect(java.util.stream.Collectors.groupingBy(
                        ProviderFixture::weekNumber,
                        java.util.stream.Collectors.minBy(java.util.Comparator.comparing(ProviderFixture::kickoffAt))
                ))
                .forEach((week, earliest) -> earliest.ifPresent(pf ->
                        log.info("syncForCompetition: PL week {} earliest kickoff={} started={}",
                                week, pf.kickoffAt(), startedWeeks.contains(week))));

        if (!startedWeeks.isEmpty()) {
            log.info("syncForCompetition: skipping PL week(s) {} — already kicked off",
                    startedWeeks.stream().sorted().toList());
        }

        // Also skip any PL week whose earliest kickoff is before the competition start date.
        // e.g. competition starts May 10 but PL week 36 has a game on May 9 — skip that whole week.
        java.util.Map<Integer, LocalDateTime> allWeekEarliestKickoff = new java.util.HashMap<>();
        merged.values().forEach(pf -> allWeekEarliestKickoff.merge(pf.weekNumber(), pf.kickoffAt(),
                (a, b) -> a.isBefore(b) ? a : b));

        java.util.Set<Integer> weeksStartingBeforeCompStart = allWeekEarliestKickoff.entrySet().stream()
                .filter(e -> competition.getStartDate() != null
                        && e.getValue().toLocalDate().isBefore(competition.getStartDate()))
                .map(java.util.Map.Entry::getKey)
                .collect(java.util.stream.Collectors.toSet());

        if (!weeksStartingBeforeCompStart.isEmpty()) {
            log.info("syncForCompetition: skipping PL week(s) {} — earliest kickoff is before competition start date {}",
                    weeksStartingBeforeCompStart.stream().sorted().toList(), competition.getStartDate());
        }

        java.util.Set<Integer> allSkippedWeeks = new java.util.HashSet<>();
        allSkippedWeeks.addAll(startedWeeks);
        allSkippedWeeks.addAll(weeksStartingBeforeCompStart);

        // Filter to fixtures on or after the competition start date, excluding all skipped weeks
        List<ProviderFixture> eligible = merged.values().stream()
                .filter(pf -> competition.getStartDate() == null
                        || !pf.kickoffAt().toLocalDate().isBefore(competition.getStartDate()))
                .filter(pf -> !allSkippedWeeks.contains(pf.weekNumber()))
                .sorted(java.util.Comparator.comparingInt(ProviderFixture::weekNumber)
                        .thenComparing(ProviderFixture::kickoffAt))
                .toList();

        if (eligible.isEmpty()) {
            log.warn("No future fixtures found for competition {} — all eligible weeks have already started or no fixtures after start date",
                    competition.getId());
            return 0;
        }

        // Minimum playable fixtures required to constitute a valid gameweek
        final int MIN_PLAYABLE_FIXTURES = 3;

        // Count playable (non-postponed, non-cancelled) fixtures per provider week
        java.util.Map<Integer, Long> playableCountPerWeek = eligible.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                        ProviderFixture::weekNumber,
                        java.util.stream.Collectors.filtering(
                                pf -> !"POSTPONED".equals(pf.status()) && !"CANCELLED".equals(pf.status()),
                                java.util.stream.Collectors.counting()
                        )
                ));

        // Only map provider weeks that have enough playable fixtures
        java.util.Set<Integer> validProviderWeeks = playableCountPerWeek.entrySet().stream()
                .filter(e -> e.getValue() >= MIN_PLAYABLE_FIXTURES)
                .map(java.util.Map.Entry::getKey)
                .collect(java.util.stream.Collectors.toSet());

        if (validProviderWeeks.isEmpty()) {
            log.warn("No valid gameweeks found for competition {} — all weeks have fewer than {} playable fixtures",
                    competition.getId(), MIN_PLAYABLE_FIXTURES);
            return 0;
        }

        log.info("syncForCompetition: {} provider weeks qualify as valid gameweeks (≥{} playable fixtures): {}",
                validProviderWeeks.size(), MIN_PLAYABLE_FIXTURES, validProviderWeeks.stream().sorted().toList());

        // Build providerWeek → compGwNumber mapping, anchored to existing gameweeks.
        // For each existing gameweek, find which provider week's fixtures are stored in it
        // so we don't remap on re-sync.
        java.util.LinkedHashMap<Integer, Integer> providerWeekToCompGw = new java.util.LinkedHashMap<>();

        // Load existing gameweeks and their fixtures to detect existing provider week mappings
        List<Gameweek> existingGameweeks = gameweekRepository.findByCompetitionIdOrderByWeekNumberAsc(competition.getId());
        for (Gameweek existingGw : existingGameweeks) {
            List<com.lastmanstanding.entity.Fixture> existingFixtures = fixtureRepository.findByGameweekId(existingGw.getId());
            // Determine which provider week these fixtures belong to by matching externalFixtureId
            for (ProviderFixture pf : eligible) {
                boolean matches = existingFixtures.stream()
                        .anyMatch(ef -> ef.getExternalFixtureId().equals(pf.externalFixtureId()));
                if (matches) {
                    providerWeekToCompGw.put(pf.weekNumber(), existingGw.getWeekNumber());
                    break;
                }
            }
        }

        // Assign new GW numbers only for provider weeks not yet mapped
        int nextGwNum = existingGameweeks.stream().mapToInt(Gameweek::getWeekNumber).max().orElse(0) + 1;
        for (ProviderFixture pf : eligible) {
            if (validProviderWeeks.contains(pf.weekNumber())
                    && !providerWeekToCompGw.containsKey(pf.weekNumber())) {
                providerWeekToCompGw.put(pf.weekNumber(), nextGwNum++);
            }
        }

        // Earliest kickoff per provider week (for lockAt calculation)
        java.util.Map<Integer, LocalDateTime> weekEarliestKickoff = new java.util.HashMap<>();
        for (ProviderFixture pf : eligible) {
            weekEarliestKickoff.merge(pf.weekNumber(), pf.kickoffAt(),
                    (a, b) -> a.isBefore(b) ? a : b);
        }

        int count = 0;
        for (ProviderFixture pf : eligible) {
            // Skip fixtures from weeks that didn't qualify as valid gameweeks
            if (!providerWeekToCompGw.containsKey(pf.weekNumber())) continue;

            Team homeTeam = teamRepository.findByExternalTeamId(pf.homeTeamExternalId()).orElse(null);
            Team awayTeam = teamRepository.findByExternalTeamId(pf.awayTeamExternalId()).orElse(null);
            if (homeTeam == null || awayTeam == null) continue;

            FixtureStatus status;
            try { status = FixtureStatus.valueOf(pf.status()); }
            catch (IllegalArgumentException e) { status = FixtureStatus.SCHEDULED; }

            int compWeekNumber = providerWeekToCompGw.get(pf.weekNumber());

            Gameweek gw = gameweekRepository.findByCompetitionIdAndWeekNumber(
                    competition.getId(), compWeekNumber).orElse(null);

            if (gw == null) {
                LocalDateTime earliest = weekEarliestKickoff.get(pf.weekNumber());
                LocalDateTime lockAt   = earliest.minusHours(1);
                LocalDateTime weekStart = earliest.toLocalDate().atStartOfDay();
                gw = new Gameweek(competition, compWeekNumber,
                        lockAt, weekStart, weekStart.plusDays(3), GameweekStatus.UPCOMING);
                gw = gameweekRepository.save(gw);
            }

            Fixture existing = fixtureRepository
                    .findByExternalFixtureIdAndGameweekId(pf.externalFixtureId(), gw.getId())
                    .orElse(null);

            if (existing != null) {
                existing.setImportedHomeTeam(homeTeam);
                existing.setImportedAwayTeam(awayTeam);
                existing.setImportedKickoffAt(pf.kickoffAt());
                existing.setImportedStatus(status);
                existing.setImportedScoreHome(pf.scoreHome());
                existing.setImportedScoreAway(pf.scoreAway());
                existing.setLastSyncedAt(LocalDateTime.now());
                fixtureRepository.save(existing);
            } else {
                Fixture f = new Fixture(gw, pf.externalFixtureId(), homeTeam, awayTeam,
                        pf.kickoffAt(), status);
                f.setImportedScoreHome(pf.scoreHome());
                f.setImportedScoreAway(pf.scoreAway());
                f.setLastSyncedAt(LocalDateTime.now());
                fixtureRepository.save(f);
                count++;
            }
        }

        log.info("Synced {} fixtures for competition {} ({})", count, competition.getId(), competition.getName());
        return count;
    }

    private void upsertFixtures(List<ProviderFixture> providerFixtures) {
        List<Competition> competitions = competitionRepository.findByStatusInOrderByStartDateAsc(
                List.of(CompetitionStatus.UPCOMING, CompetitionStatus.ACTIVE));

        java.time.LocalDateTime now = java.time.LocalDateTime.now(java.time.ZoneOffset.UTC);

        // Weeks where any fixture has already kicked off — same check used in syncForCompetition
        java.util.Set<Integer> startedWeeks = providerFixtures.stream()
                .filter(pf -> pf.kickoffAt().isBefore(now))
                .map(ProviderFixture::weekNumber)
                .collect(java.util.stream.Collectors.toSet());

        for (Competition comp : competitions) {

            // Skip weeks whose earliest kickoff is before this competition's start date
            // e.g. comp starts May 10 but PL week 36 opens on May 9 — skip that whole week
            java.util.Map<Integer, LocalDateTime> allWeekEarliest = new java.util.HashMap<>();
            providerFixtures.forEach(pf -> allWeekEarliest.merge(pf.weekNumber(), pf.kickoffAt(),
                    (a, b) -> a.isBefore(b) ? a : b));

            java.util.Set<Integer> weeksTooEarly = allWeekEarliest.entrySet().stream()
                    .filter(e -> comp.getStartDate() != null
                            && e.getValue().toLocalDate().isBefore(comp.getStartDate()))
                    .map(java.util.Map.Entry::getKey)
                    .collect(java.util.stream.Collectors.toSet());

            java.util.Set<Integer> allSkipped = new java.util.HashSet<>();
            allSkipped.addAll(startedWeeks);
            allSkipped.addAll(weeksTooEarly);

            // Filter: on/after comp start date AND not in a skipped week
            List<ProviderFixture> eligible = providerFixtures.stream()
                    .filter(pf -> comp.getStartDate() == null
                            || !pf.kickoffAt().toLocalDate().isBefore(comp.getStartDate()))
                    .filter(pf -> !allSkipped.contains(pf.weekNumber()))
                    .sorted(java.util.Comparator.comparingInt(ProviderFixture::weekNumber)
                            .thenComparing(ProviderFixture::kickoffAt))
                    .toList();

            // Only include weeks with at least 3 playable fixtures
            final int MIN_PLAYABLE = 3;
            java.util.Set<Integer> validWeeks = new java.util.HashSet<>();
            providerFixtures.stream() // check ALL fixtures for valid-week status, not just eligible
                    .collect(java.util.stream.Collectors.groupingBy(
                            ProviderFixture::weekNumber,
                            java.util.stream.Collectors.filtering(
                                    pf -> !"POSTPONED".equals(pf.status()) && !"CANCELLED".equals(pf.status()),
                                    java.util.stream.Collectors.counting()
                            )
                    ))
                    .forEach((week, cnt) -> { if (cnt >= MIN_PLAYABLE) validWeeks.add(week); });

            // Anchor to existing gameweek mappings — never remap a provider week that is
            // already stored under a competition GW to prevent fixtures shifting between weeks
            java.util.LinkedHashMap<Integer, Integer> providerWeekToCompGw = new java.util.LinkedHashMap<>();

            List<Gameweek> existingGameweeks = gameweekRepository
                    .findByCompetitionIdOrderByWeekNumberAsc(comp.getId());

            for (Gameweek existingGw : existingGameweeks) {
                List<com.lastmanstanding.entity.Fixture> existingFixtures =
                        fixtureRepository.findByGameweekId(existingGw.getId());
                for (ProviderFixture pf : eligible) {
                    boolean matches = existingFixtures.stream()
                            .anyMatch(ef -> ef.getExternalFixtureId().equals(pf.externalFixtureId()));
                    if (matches) {
                        providerWeekToCompGw.put(pf.weekNumber(), existingGw.getWeekNumber());
                        break;
                    }
                }
            }

            // Assign new GW numbers only for provider weeks not yet mapped
            int nextGw = existingGameweeks.stream().mapToInt(Gameweek::getWeekNumber).max().orElse(0) + 1;
            for (ProviderFixture pf : eligible) {
                if (validWeeks.contains(pf.weekNumber())
                        && !providerWeekToCompGw.containsKey(pf.weekNumber())) {
                    providerWeekToCompGw.put(pf.weekNumber(), nextGw++);
                }
            }

            // Earliest kickoff per provider week (for lockAt)
            java.util.Map<Integer, LocalDateTime> weekEarliestKickoff = new java.util.HashMap<>();
            for (ProviderFixture pf : eligible) {
                weekEarliestKickoff.merge(pf.weekNumber(), pf.kickoffAt(),
                        (a, b) -> a.isBefore(b) ? a : b);
            }

            for (ProviderFixture pf : eligible) {
                if (!providerWeekToCompGw.containsKey(pf.weekNumber())) continue;

                Team homeTeam = teamRepository.findByExternalTeamId(pf.homeTeamExternalId()).orElse(null);
                Team awayTeam = teamRepository.findByExternalTeamId(pf.awayTeamExternalId()).orElse(null);
                if (homeTeam == null || awayTeam == null) {
                    log.warn("Skipping fixture {} — teams not found", pf.externalFixtureId());
                    continue;
                }

                FixtureStatus status;
                try {
                    status = FixtureStatus.valueOf(pf.status());
                } catch (IllegalArgumentException e) {
                    status = FixtureStatus.SCHEDULED;
                }

                int compWeekNumber = providerWeekToCompGw.get(pf.weekNumber());

                Gameweek gw = gameweekRepository
                        .findByCompetitionIdAndWeekNumber(comp.getId(), compWeekNumber)
                        .orElse(null);

                if (gw == null) {
                    LocalDateTime earliestKickoff = weekEarliestKickoff.get(pf.weekNumber());
                    LocalDateTime lockAt = earliestKickoff.minusHours(1);
                    LocalDateTime weekStart = earliestKickoff.toLocalDate().atStartOfDay();
                    gw = new Gameweek(comp, compWeekNumber,
                            lockAt, weekStart, weekStart.plusDays(3), GameweekStatus.UPCOMING);
                    gw = gameweekRepository.save(gw);
                }

                Fixture fixture = fixtureRepository
                        .findByExternalFixtureIdAndGameweekId(pf.externalFixtureId(), gw.getId())
                        .orElse(null);

                if (fixture != null) {
                    fixture.setImportedHomeTeam(homeTeam);
                    fixture.setImportedAwayTeam(awayTeam);
                    fixture.setImportedKickoffAt(pf.kickoffAt());
                    fixture.setImportedStatus(status);
                    fixture.setImportedScoreHome(pf.scoreHome());
                    fixture.setImportedScoreAway(pf.scoreAway());
                    fixture.setLastSyncedAt(LocalDateTime.now());
                    fixtureRepository.save(fixture);
                } else {
                    fixture = new Fixture(gw, pf.externalFixtureId(), homeTeam, awayTeam,
                            pf.kickoffAt(), status);
                    fixture.setImportedScoreHome(pf.scoreHome());
                    fixture.setImportedScoreAway(pf.scoreAway());
                    fixture.setLastSyncedAt(LocalDateTime.now());
                    fixtureRepository.save(fixture);
                }
            }
        }
    }
}
