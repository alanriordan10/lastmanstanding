package com.lastmanstanding.service;

import com.lastmanstanding.entity.*;
import com.lastmanstanding.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

/**
 * Core business logic: processes gameweek results, handles auto-assign, determines elimination.
 */
@Service
public class GameweekProcessingService {

    private static final Logger log = LoggerFactory.getLogger(GameweekProcessingService.class);
    /** Keep at least this many UPCOMING gameweeks ahead at all times */
    private static final int MIN_UPCOMING_BUFFER = 3;

    private final GameweekRepository gameweekRepository;
    private final FixtureRepository fixtureRepository;
    private final PickRepository pickRepository;
    private final PickResultRepository pickResultRepository;
    private final CompetitionParticipantRepository participantRepository;
    private final TeamRepository teamRepository;
    private final CompetitionRepository competitionRepository;
    private final FixtureSyncService fixtureSyncService;
    private final GameweekEmailService gameweekEmailService;

    public GameweekProcessingService(GameweekRepository gameweekRepository,
                                     FixtureRepository fixtureRepository,
                                     PickRepository pickRepository,
                                     PickResultRepository pickResultRepository,
                                     CompetitionParticipantRepository participantRepository,
                                     TeamRepository teamRepository,
                                     CompetitionRepository competitionRepository,
                                     FixtureSyncService fixtureSyncService,
                                     GameweekEmailService gameweekEmailService) {
        this.gameweekRepository = gameweekRepository;
        this.fixtureRepository = fixtureRepository;
        this.pickRepository = pickRepository;
        this.pickResultRepository = pickResultRepository;
        this.participantRepository = participantRepository;
        this.teamRepository = teamRepository;
        this.competitionRepository = competitionRepository;
        this.fixtureSyncService = fixtureSyncService;
        this.gameweekEmailService = gameweekEmailService;
    }

    /**
     * Lock picks at lock time, handle auto-assign for missed picks.
     */
    @Transactional
    public void lockGameweek(Long gameweekId) {
        // Re-fetch inside transaction so all lazy proxies (Competition etc.) are in session
        Gameweek gw = gameweekRepository.findById(gameweekId).orElseThrow();
        if (gw.getStatus() != GameweekStatus.UPCOMING) return;
        if (LocalDateTime.now().isBefore(gw.getLockAt())) return;
        doLockGameweek(gw);
    }

    /**
     * Force-lock a gameweek immediately, bypassing the lock-time check.
     * Used for simulation/testing purposes only.
     */
    @Transactional
    public void forceLockGameweek(Long gameweekId) {
        Gameweek gw = gameweekRepository.findById(gameweekId).orElseThrow();
        if (gw.getStatus() != GameweekStatus.UPCOMING) return;
        doLockGameweek(gw);
    }

    private void doLockGameweek(Gameweek gw) {
        Competition comp = competitionRepository.findById(gw.getCompetition().getId()).orElseThrow();
        List<CompetitionParticipant> activeParticipants =
                participantRepository.findByCompetitionIdAndStatus(comp.getId(), ParticipantStatus.ACTIVE);

        List<Fixture> fixtures = fixtureRepository.findByGameweekId(gw.getId());

        // Get all teams playing this gameweek
        Set<Long> teamsWithFixture = new HashSet<>();
        for (Fixture f : fixtures) {
            teamsWithFixture.add(f.getEffectiveHomeTeam().getId());
            teamsWithFixture.add(f.getEffectiveAwayTeam().getId());
        }

        for (CompetitionParticipant cp : activeParticipants) {
            Optional<Pick> existingPick = pickRepository.findByCompetitionIdAndUserIdAndGameweekId(
                    comp.getId(), cp.getUser().getId(), gw.getId());

            if (existingPick.isPresent()) {
                // Lock the pick
                Pick pick = existingPick.get();
                pick.setLocked(true);
                pickRepository.save(pick);
            } else {
                // Missed pick handling
                handleMissedPick(comp, gw, cp, teamsWithFixture);
            }
        }

        gw.setStatus(GameweekStatus.LOCKED);
        gameweekRepository.save(gw);
        log.info("Locked gameweek {} for competition {}", gw.getWeekNumber(), comp.getId());
    }

    private void handleMissedPick(Competition comp, Gameweek gw,
                                  CompetitionParticipant cp, Set<Long> teamsWithFixture) {
        if (comp.getMissedPickMode() == MissedPickMode.AUTO_ASSIGN) {
            // Auto-assign: first available team alphabetically that has a fixture
            List<Long> usedTeamIds = pickRepository.findUsedTeamIds(comp.getId(), cp.getUser().getId());
            List<Team> allTeams = teamRepository.findAllByOrderByNameAsc();

            Team autoTeam = null;
            for (Team t : allTeams) {
                if (!usedTeamIds.contains(t.getId()) && teamsWithFixture.contains(t.getId())) {
                    autoTeam = t;
                    break;
                }
            }

            if (autoTeam != null) {
                Pick pick = new Pick(comp, cp.getUser(), gw, autoTeam, PickSource.AUTO, true);
                pick = pickRepository.save(pick);
                PickResult pr = new PickResult(pick, PickOutcome.PENDING);
                pickResultRepository.save(pr);
                log.info("Auto-assigned team {} to user {} for GW{}", autoTeam.getName(),
                        cp.getUser().getUsername(), gw.getWeekNumber());
            } else {
                // No available teams — eliminate
                eliminateParticipant(cp, gw);
                log.info("No teams available for auto-assign — eliminated user {}", cp.getUser().getUsername());
            }
        } else {
            // ELIMINATE mode
            eliminateParticipant(cp, gw);
            log.info("Missed pick (ELIMINATE mode) — eliminated user {}", cp.getUser().getUsername());
        }
    }

    /**
     * Process results for a completed gameweek.
     */
    @Transactional
    public void processGameweekResults(Long gameweekId) {
        processGameweekResults(gameweekId, false);
    }

    /**
     * Process results for a completed gameweek.
     * @param skipAutoComplete if true, won't auto-complete the competition even if only 1 participant remains (for testing)
     */
    @Transactional
    public void processGameweekResults(Long gameweekId, boolean skipAutoComplete) {
        // Re-fetch inside transaction so all lazy proxies (Competition etc.) are in session
        Gameweek gw = gameweekRepository.findById(gameweekId).orElseThrow();
        if (gw.getStatus() != GameweekStatus.LOCKED && gw.getStatus() != GameweekStatus.IN_PROGRESS) return;

        Competition comp = competitionRepository.findById(gw.getCompetition().getId()).orElseThrow();
        List<Fixture> fixtures = fixtureRepository.findByGameweekId(gw.getId());

        // Check if all fixtures are finished or postponed
        boolean allResolved = fixtures.stream().allMatch(f -> {
            FixtureStatus s = f.getEffectiveStatus();
            return s == FixtureStatus.FINISHED || s == FixtureStatus.POSTPONED || s == FixtureStatus.CANCELLED;
        });

        // If no fixtures are FINISHED yet, don't process results — wait for actual match results
        // (handles the case where all fixtures were postponed before the gameweek even started)
        long finishedCount = fixtures.stream()
                .filter(f -> f.getEffectiveStatus() == FixtureStatus.FINISHED)
                .count();

        if (!allResolved) {
            // Move to IN_PROGRESS if any have started
            boolean anyStarted = fixtures.stream().anyMatch(f ->
                    f.getEffectiveStatus() == FixtureStatus.IN_PLAY ||
                            f.getEffectiveStatus() == FixtureStatus.FINISHED);
            if (anyStarted && gw.getStatus() == GameweekStatus.LOCKED) {
                gw.setStatus(GameweekStatus.IN_PROGRESS);
                gameweekRepository.save(gw);
            }
            return;
        }

        // All fixtures are resolved — but if none are FINISHED (all postponed/cancelled),
        // wait; the postponed fixtures may be rescheduled and we shouldn't complete the GW yet
        if (finishedCount == 0) {
            log.info("GW{} for competition {} has all fixtures postponed/cancelled — waiting for reschedule",
                    gw.getWeekNumber(), comp.getId());
            return;
        }

        // Build a map: teamId -> fixture result
        Map<Long, FixtureOutcome> teamOutcomes = new HashMap<>();
        for (Fixture f : fixtures) {
            FixtureStatus status = f.getEffectiveStatus();
            Long homeTeamId = f.getEffectiveHomeTeam().getId();
            Long awayTeamId = f.getEffectiveAwayTeam().getId();

            if (status == FixtureStatus.POSTPONED || status == FixtureStatus.CANCELLED) {
                teamOutcomes.put(homeTeamId, FixtureOutcome.POSTPONED);
                teamOutcomes.put(awayTeamId, FixtureOutcome.POSTPONED);
            } else if (status == FixtureStatus.FINISHED) {
                Integer sh = f.getEffectiveScoreHome();
                Integer sa = f.getEffectiveScoreAway();
                if (sh == null || sa == null) continue;

                if (sh > sa) {
                    teamOutcomes.put(homeTeamId, FixtureOutcome.WIN);
                    teamOutcomes.put(awayTeamId, FixtureOutcome.LOSS);
                } else if (sh < sa) {
                    teamOutcomes.put(homeTeamId, FixtureOutcome.LOSS);
                    teamOutcomes.put(awayTeamId, FixtureOutcome.WIN);
                } else {
                    teamOutcomes.put(homeTeamId, FixtureOutcome.DRAW);
                    teamOutcomes.put(awayTeamId, FixtureOutcome.DRAW);
                }
            }
        }

        // Process each pick and track who would be eliminated
        List<Pick> picks = pickRepository.findByCompetitionIdAndGameweekId(comp.getId(), gw.getId());
        List<CompetitionParticipant> toEliminate = new ArrayList<>();
        List<PickResult> allResults = new ArrayList<>();

        for (Pick pick : picks) {
            PickResult pr = pickResultRepository.findByPickId(pick.getId())
                    .orElse(new PickResult(pick, PickOutcome.PENDING));

            if (pr.getOutcome() != PickOutcome.PENDING) continue; // Already resolved

            Long pickedTeamId = pick.getTeam().getId();
            FixtureOutcome outcome = teamOutcomes.get(pickedTeamId);

            if (outcome == null) {
                // Team not found in fixtures — treat as postponed advance
                pr.setOutcome(PickOutcome.POSTPONED_ADVANCE);
            } else {
                switch (outcome) {
                    case WIN -> pr.setOutcome(PickOutcome.ADVANCE);
                    case POSTPONED -> pr.setOutcome(PickOutcome.POSTPONED_ADVANCE);
                    case DRAW, LOSS -> {
                        pr.setOutcome(PickOutcome.ELIMINATED);
                        // Track for elimination (don't eliminate yet)
                        CompetitionParticipant cp = participantRepository
                                .findByCompetitionIdAndUserId(comp.getId(), pick.getUser().getId())
                                .orElse(null);
                        if (cp != null && cp.getStatus() == ParticipantStatus.ACTIVE) {
                            toEliminate.add(cp);
                        }
                    }
                }
            }

            pr.setResolvedAt(LocalDateTime.now());
            allResults.add(pr);
        }

        // Check if ALL active participants are being eliminated this gameweek
        long activeCountBeforeElimination = participantRepository.countByCompetitionIdAndStatus(
                comp.getId(), ParticipantStatus.ACTIVE);

        log.info("GW{} elimination check: {} to eliminate, {} active before, condition check: toEliminate={}, activeCount={}",
                gw.getWeekNumber(), toEliminate.size(), activeCountBeforeElimination,
                !toEliminate.isEmpty(), activeCountBeforeElimination > 1);
        log.info("Bye logic will trigger: {}",
                !toEliminate.isEmpty() && toEliminate.size() == activeCountBeforeElimination && activeCountBeforeElimination > 1);

        if (!toEliminate.isEmpty() && toEliminate.size() == activeCountBeforeElimination && activeCountBeforeElimination > 1) {
            // Everyone who was active is being eliminated — grant them all a BYE
            log.info("🎯 BYE LOGIC TRIGGERED: ALL {} active participants would be eliminated in GW{} — granting BYE to all",
                    toEliminate.size(), gw.getWeekNumber());

            // Change all ELIMINATED outcomes to ADVANCE (bye)
            for (PickResult pr : allResults) {
                if (pr.getOutcome() == PickOutcome.ELIMINATED) {
                    pr.setOutcome(PickOutcome.ADVANCE);
                    log.info("✓ Granted BYE to {}", pr.getPick().getUser().getUsername());
                }
            }

            // Don't eliminate anyone
            toEliminate.clear();
            log.info("✓ BYE granted to all {} participants - toEliminate list cleared", activeCountBeforeElimination);

            // Mark the gameweek as having a bye granted
            gw.setByeGranted(true);
            gameweekRepository.save(gw);

            // IMPORTANT: Create auto-assigned picks for the NEXT gameweek
            // Otherwise they'll be eliminated for "missed pick" when next GW is processed
            List<Gameweek> nextGameweeks = gameweekRepository.findByCompetitionIdOrderByWeekNumberAsc(comp.getId())
                    .stream()
                    .filter(nextGw -> nextGw.getWeekNumber() == gw.getWeekNumber() + 1)
                    .toList();

            if (!nextGameweeks.isEmpty()) {
                Gameweek nextGw = nextGameweeks.get(0);
                List<Fixture> nextGwFixtures = fixtureRepository.findByGameweekId(nextGw.getId());
                Set<Long> nextGwTeams = new HashSet<>();
                for (Fixture f : nextGwFixtures) {
                    nextGwTeams.add(f.getEffectiveHomeTeam().getId());
                    nextGwTeams.add(f.getEffectiveAwayTeam().getId());
                }

                List<Team> allTeams = teamRepository.findAllByOrderByNameAsc();

                // Create auto-pick for each bye recipient for the next gameweek
                for (PickResult pr : allResults) {
                    if (pr.getOutcome() == PickOutcome.ADVANCE) {
                        User user = pr.getPick().getUser();

                        // Check if they already have a pick for next gameweek
                        Optional<Pick> existingNextPick = pickRepository.findByCompetitionIdAndUserIdAndGameweekId(
                                comp.getId(), user.getId(), nextGw.getId());

                        if (existingNextPick.isEmpty()) {
                            // Find first available team they haven't used
                            List<Long> usedTeamIds = pickRepository.findUsedTeamIds(comp.getId(), user.getId());
                            Team autoTeam = null;
                            for (Team t : allTeams) {
                                if (!usedTeamIds.contains(t.getId()) && nextGwTeams.contains(t.getId())) {
                                    autoTeam = t;
                                    break;
                                }
                            }

                            if (autoTeam != null) {
                                Pick autoPick = new Pick(comp, user, nextGw, autoTeam, PickSource.AUTO, false);
                                pickRepository.save(autoPick);
                                PickResult autoResult = new PickResult(autoPick, PickOutcome.PENDING);
                                pickResultRepository.save(autoResult);
                                log.info("✓ Auto-assigned {} to {} for next GW{} (bye follow-up)",
                                        autoTeam.getName(), user.getUsername(), nextGw.getWeekNumber());
                            } else {
                                log.warn("⚠ No available team for {} in next GW{} after bye",
                                        user.getUsername(), nextGw.getWeekNumber());
                            }
                        }
                    }
                }
            }
        } else {
            log.info("Bye logic NOT triggered - proceeding with {} eliminations", toEliminate.size());
        }

        // Save all results
        pickResultRepository.saveAll(allResults);

        // Now actually eliminate the participants (if any)
        for (CompetitionParticipant cp : toEliminate) {
            eliminateParticipant(cp, gw);
        }

        // Handle postponed-consumes-team: if competition config says NO, delete the pick's team usage
        // (This is handled by the "used teams" query which checks all picks regardless)
        // If postponedConsumesTeam=false, we need to allow re-picking that team.
        // We'll handle this in PickService by checking the competition config + pick result.

        gw.setStatus(GameweekStatus.COMPLETED);
        gameweekRepository.save(gw);

        // ── Auto-buffer: ensure there are always enough upcoming gameweeks ──────────
        // After a gameweek completes, sync the next batch of fixtures from the provider
        // if fewer than MIN_UPCOMING_BUFFER weeks are still UPCOMING.
        ensureUpcomingBuffer(comp);

        // Send result emails to opted-in participants
        gameweekEmailService.sendGameweekResultEmails(comp, gw);

        // Check if competition should be completed (1 or fewer active participants)
        if (!skipAutoComplete) {
            checkCompetitionCompletion(comp);
        } else {
            log.info("Skipped auto-completion check for competition {} (testing mode)", comp.getId());
        }

        log.info("Processed results for GW{} in competition {}", gw.getWeekNumber(), comp.getId());
    }

    private void eliminateParticipant(CompetitionParticipant cp, Gameweek gw) {
        cp.setStatus(ParticipantStatus.ELIMINATED);
        cp.setEliminatedWeek(gw.getWeekNumber());
        participantRepository.save(cp);

        // Delete all picks for future gameweeks (week > current week)
        // User is eliminated and should not have picks for gameweeks they won't play
        Long competitionId = cp.getCompetition().getId();
        Long userId = cp.getUser().getId();
        Integer eliminatedWeekNumber = gw.getWeekNumber();

        List<Gameweek> futureGameweeks = gameweekRepository.findByCompetitionIdOrderByWeekNumberAsc(competitionId)
                .stream()
                .filter(futureGw -> futureGw.getWeekNumber() > eliminatedWeekNumber)
                .toList();

        int deletedCount = 0;
        for (Gameweek futureGw : futureGameweeks) {
            Optional<Pick> futurePick = pickRepository.findByCompetitionIdAndUserIdAndGameweekId(
                    competitionId, userId, futureGw.getId());
            if (futurePick.isPresent()) {
                Pick pick = futurePick.get();
                // Delete the pick result first if it exists (foreign key constraint)
                pickResultRepository.findByPickId(pick.getId()).ifPresent(pickResultRepository::delete);
                // Delete the pick
                pickRepository.delete(pick);
                deletedCount++;
            }
        }

        if (deletedCount > 0) {
            log.info("Deleted {} future pick(s) for eliminated user {} in competition {}",
                    deletedCount, cp.getUser().getUsername(), competitionId);
        }
    }

    private void checkCompetitionCompletion(Competition comp) {
        long activeCount = participantRepository.countByCompetitionIdAndStatus(comp.getId(), ParticipantStatus.ACTIVE);
        if (activeCount <= 1) {
            comp.setStatus(CompetitionStatus.COMPLETED);
            competitionRepository.save(comp);

            if (activeCount == 1) {
                CompetitionParticipant winner = participantRepository
                        .findByCompetitionIdAndStatus(comp.getId(), ParticipantStatus.ACTIVE)
                        .get(0);
                winner.setStatus(ParticipantStatus.WINNER);
                participantRepository.save(winner);
                log.info("Competition {} completed! Winner: {}", comp.getId(), winner.getUser().getUsername());
            } else {
                log.info("Competition {} completed with no remaining participants", comp.getId());
            }
        }
    }

    /**
     * Ensure there are always at least MIN_UPCOMING_BUFFER gameweeks ahead.
     * Called after each gameweek completes so new fixtures are pulled from the provider
     * automatically — no manual sync needed.
     */
    private void ensureUpcomingBuffer(Competition comp) {
        if (comp.getStatus() == CompetitionStatus.COMPLETED) return;

        List<Gameweek> allGws = gameweekRepository.findByCompetitionIdOrderByWeekNumberAsc(comp.getId());

        long upcomingCount = allGws.stream()
                .filter(g -> g.getStatus() == GameweekStatus.UPCOMING)
                .count();

        if (upcomingCount < MIN_UPCOMING_BUFFER) {
            log.info("Competition {} has only {} upcoming gameweek(s) — syncing next fixtures from provider",
                    comp.getId(), upcomingCount);
            try {
                int added = fixtureSyncService.syncForCompetition(comp);
                log.info("Auto-buffered {} new fixture(s) for competition {}", added, comp.getId());

                // Re-check after sync
                long updatedCount = gameweekRepository.findByCompetitionIdOrderByWeekNumberAsc(comp.getId())
                        .stream()
                        .filter(g -> g.getStatus() == GameweekStatus.UPCOMING)
                        .count();

                if (updatedCount < MIN_UPCOMING_BUFFER) {
                    log.info("Competition {} — provider has no further fixtures available yet. " +
                            "New gameweeks will be added automatically when the next fixture batch is published.",
                            comp.getId());
                }
            } catch (Exception e) {
                log.warn("Could not auto-buffer fixtures for competition {}: {}", comp.getId(), e.getMessage());
            }
        } else {
            log.debug("Competition {} has {} upcoming gameweeks — no buffer sync needed",
                    comp.getId(), upcomingCount);
        }
    }

    private enum FixtureOutcome {
        WIN, LOSS, DRAW, POSTPONED
    }
}
