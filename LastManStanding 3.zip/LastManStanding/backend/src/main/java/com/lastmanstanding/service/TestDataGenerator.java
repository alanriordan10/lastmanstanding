package com.lastmanstanding.service;

import com.lastmanstanding.entity.*;
import com.lastmanstanding.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Random;

/**
 * Service to generate large number of test users for scale testing.
 */
@Service
public class TestDataGenerator {

    private static final Logger log = LoggerFactory.getLogger(TestDataGenerator.class);

    private final UserRepository userRepository;
    private final CompetitionRepository competitionRepository;
    private final CompetitionParticipantRepository participantRepository;
    private final GameweekRepository gameweekRepository;
    private final PickRepository pickRepository;
    private final TeamRepository teamRepository;
    private final PasswordEncoder passwordEncoder;

    public TestDataGenerator(UserRepository userRepository,
                            CompetitionRepository competitionRepository,
                            CompetitionParticipantRepository participantRepository,
                            GameweekRepository gameweekRepository,
                            PickRepository pickRepository,
                            TeamRepository teamRepository,
                            PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.competitionRepository = competitionRepository;
        this.participantRepository = participantRepository;
        this.gameweekRepository = gameweekRepository;
        this.pickRepository = pickRepository;
        this.teamRepository = teamRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Generate N test users and join them to a specific competition.
     * Creates picks for specified gameweeks to enable testing.
     */
    @Transactional
    public GenerationResult generateTestUsers(Long competitionId, int count, List<Integer> gameweeksToSeedPicks) {
        log.info("Generating {} test users for competition {}", count, competitionId);

        Competition comp = competitionRepository.findById(competitionId)
                .orElseThrow(() -> new IllegalArgumentException("Competition not found"));

        List<Team> allTeams = teamRepository.findAllByOrderByNameAsc();
        if (allTeams.isEmpty()) {
            throw new IllegalStateException("No teams available");
        }

        Random random = new Random();
        int usersCreated = 0;
        int usersJoined = 0;
        int picksCreated = 0;

        // Pre-hash password once
        String passwordHash = passwordEncoder.encode("password123");

        for (int i = 1; i <= count; i++) {
            String username = String.format("testuser%03d", i);
            String email = String.format("testuser%03d@lms.com", i);

            // Create user if doesn't exist
            User user;
            if (userRepository.existsByEmail(email)) {
                user = userRepository.findByEmail(email).orElseThrow();
            } else {
                user = new User(email, username, passwordHash, Role.USER);
                user = userRepository.save(user);
                usersCreated++;
            }

            // Join competition if not already joined
            if (!participantRepository.existsByCompetitionIdAndUserId(competitionId, user.getId())) {
                CompetitionParticipant cp = new CompetitionParticipant(comp, user, ParticipantStatus.ACTIVE);
                participantRepository.save(cp);
                usersJoined++;
            }

            // Create picks for specified gameweeks
            if (gameweeksToSeedPicks != null && !gameweeksToSeedPicks.isEmpty()) {
                for (Integer weekNumber : gameweeksToSeedPicks) {
                    Gameweek gw = gameweekRepository.findByCompetitionIdAndWeekNumber(competitionId, weekNumber)
                            .orElse(null);

                    if (gw != null) {
                        // Check if pick already exists
                        if (pickRepository.findByCompetitionIdAndUserIdAndGameweekId(
                                competitionId, user.getId(), gw.getId()).isEmpty()) {

                            // Get teams user hasn't picked yet
                            List<Long> usedTeamIds = pickRepository.findUsedTeamIds(competitionId, user.getId());
                            List<Team> availableTeams = allTeams.stream()
                                    .filter(t -> !usedTeamIds.contains(t.getId()))
                                    .toList();

                            if (!availableTeams.isEmpty()) {
                                Team randomTeam = availableTeams.get(random.nextInt(availableTeams.size()));
                                Pick pick = new Pick(comp, user, gw, randomTeam, PickSource.USER, true);
                                pickRepository.save(pick);
                                picksCreated++;
                            }
                        }
                    }
                }
            }

            // Log progress every 50 users
            if (i % 50 == 0) {
                log.info("Progress: {}/{} users processed", i, count);
            }
        }

        log.info("Generation complete: {} users created, {} joined, {} picks created",
                usersCreated, usersJoined, picksCreated);

        return new GenerationResult(usersCreated, usersJoined, picksCreated);
    }

    /**
     * Delete all test users (cleanup)
     */
    @Transactional
    public int cleanupTestUsers() {
        log.info("Cleaning up test users...");

        // Find all test users by username pattern
        List<User> allUsers = userRepository.findAll();
        List<User> testUsers = allUsers.stream()
                .filter(u -> u.getUsername().startsWith("testuser"))
                .toList();

        int count = testUsers.size();

        // Delete related data first (foreign key constraints)
        testUsers.forEach(u -> {
            // Delete picks
            pickRepository.findByCompetitionIdAndUserId(1L, u.getId())
                    .forEach(pick -> pickRepository.delete(pick));

            // Delete participants
            participantRepository.findByUserId(u.getId())
                    .forEach(cp -> participantRepository.delete(cp));

            // Delete user
            userRepository.delete(u);
        });

        log.info("Deleted {} test users", count);
        return count;
    }

    public record GenerationResult(int usersCreated, int participantsAdded, int picksCreated) {}
}
