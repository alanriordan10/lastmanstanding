-- =============================================================================
-- V2__add_clubs.sql
-- Adds a clubs table and links competitions to clubs for grouping/filtering
-- =============================================================================

CREATE TABLE clubs (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    name        VARCHAR(255) NOT NULL,
    description TEXT         NULL,
    created_by  BIGINT       NOT NULL,
    created_at  DATETIME     NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_clubs_name (name),
    CONSTRAINT fk_clubs_created_by FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

ALTER TABLE competitions
    ADD COLUMN club_id BIGINT NULL AFTER created_by,
    ADD INDEX idx_competitions_club_id (club_id),
    ADD CONSTRAINT fk_competitions_club FOREIGN KEY (club_id) REFERENCES clubs (id);
