-- =============================================================================
-- V5__add_club_admin_role.sql
-- Extends the users.role ENUM to include CLUB_ADMIN
-- =============================================================================

ALTER TABLE users
    MODIFY COLUMN role ENUM('USER', 'CLUB_ADMIN', 'ADMIN') NOT NULL DEFAULT 'USER';
