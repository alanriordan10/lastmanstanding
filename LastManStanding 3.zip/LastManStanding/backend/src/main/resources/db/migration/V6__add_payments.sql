-- =============================================================================
-- V6__add_payments.sql
-- Tracks Stripe payment intents for competition entry fees
-- =============================================================================

CREATE TABLE payments (
    id                   BIGINT       NOT NULL AUTO_INCREMENT,
    user_id              BIGINT       NOT NULL,
    competition_id       BIGINT       NOT NULL,
    stripe_payment_intent_id VARCHAR(255) NOT NULL,
    amount_cents         INT          NOT NULL,
    currency             VARCHAR(10)  NOT NULL DEFAULT 'eur',
    status               ENUM('PENDING', 'SUCCEEDED', 'FAILED', 'REFUNDED') NOT NULL DEFAULT 'PENDING',
    created_at           DATETIME     NOT NULL,
    updated_at           DATETIME     NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_payments_intent (stripe_payment_intent_id),
    INDEX idx_payments_user (user_id),
    INDEX idx_payments_competition (competition_id),
    CONSTRAINT fk_payments_user        FOREIGN KEY (user_id)        REFERENCES users (id),
    CONSTRAINT fk_payments_competition FOREIGN KEY (competition_id) REFERENCES competitions (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
