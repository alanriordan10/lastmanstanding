-- =============================================================================
-- V7__add_oauth_to_users.sql
-- Adds OAuth2 provider fields so users can sign in with Google, Facebook etc.
-- password_hash made nullable for OAuth-only users (no password set)
-- =============================================================================

ALTER TABLE users
    MODIFY COLUMN password_hash VARCHAR(255) NULL,
    ADD COLUMN oauth_provider    VARCHAR(50)  NULL AFTER password_hash,
    ADD COLUMN oauth_provider_id VARCHAR(255) NULL AFTER oauth_provider,
    ADD COLUMN avatar_url        VARCHAR(500) NULL AFTER oauth_provider_id,
    ADD UNIQUE KEY uk_users_oauth (oauth_provider, oauth_provider_id);
