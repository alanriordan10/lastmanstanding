-- stripe_payment_intent_id should be nullable for manual payments
ALTER TABLE payments
    MODIFY COLUMN stripe_payment_intent_id VARCHAR(255) NULL;
