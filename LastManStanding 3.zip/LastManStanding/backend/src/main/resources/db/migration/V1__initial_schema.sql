-- =============================================================================
-- V1__initial_schema.sql
-- Last Man Standing - Premier League Survival Game
-- Initial database schema
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. users
-- ---------------------------------------------------------------------------
CREATE TABLE users (
    id            BIGINT        NOT NULL AUTO_INCREMENT,
    email         VARCHAR(255)  NOT NULL,
    username      VARCHAR(100)  NOT NULL,
    password_hash VARCHAR(255)  NOT NULL,
    role          ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    created_at    DATETIME      NOT NULL,
    updated_at    DATETIME      NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_users_email    (email),
    UNIQUE KEY uk_users_username (username)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 2. teams
-- ---------------------------------------------------------------------------
CREATE TABLE teams (
    id               BIGINT       NOT NULL AUTO_INCREMENT,
    name             VARCHAR(100) NOT NULL,
    short_name       VARCHAR(10)  NULL,
    external_team_id VARCHAR(100) NULL,
    logo_url         VARCHAR(500) NULL,
    created_at       DATETIME     NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_teams_name (name),
    INDEX idx_teams_external_team_id (external_team_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 3. competitions
-- ---------------------------------------------------------------------------
CREATE TABLE competitions (
    id                     BIGINT        NOT NULL AUTO_INCREMENT,
    name                   VARCHAR(255)  NOT NULL,
    description            TEXT          NULL,
    entry_fee              DECIMAL(10,2) NOT NULL DEFAULT 0,
    status                 ENUM('UPCOMING', 'ACTIVE', 'COMPLETED') NOT NULL DEFAULT 'UPCOMING',
    missed_pick_mode       ENUM('AUTO_ASSIGN', 'ELIMINATE') NOT NULL DEFAULT 'ELIMINATE',
    postponed_consumes_team BOOLEAN      NOT NULL DEFAULT TRUE,
    start_date             DATE          NOT NULL,
    created_by             BIGINT        NOT NULL,
    created_at             DATETIME      NOT NULL,
    updated_at             DATETIME      NULL,
    PRIMARY KEY (id),
    INDEX idx_competitions_status     (status),
    INDEX idx_competitions_start_date (start_date),
    INDEX idx_competitions_created_by (created_by),
    CONSTRAINT fk_competitions_created_by
        FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 4. competition_participants
-- ---------------------------------------------------------------------------
CREATE TABLE competition_participants (
    id              BIGINT   NOT NULL AUTO_INCREMENT,
    competition_id  BIGINT   NOT NULL,
    user_id         BIGINT   NOT NULL,
    status          ENUM('ACTIVE', 'ELIMINATED', 'WINNER') NOT NULL DEFAULT 'ACTIVE',
    eliminated_week INT      NULL,
    joined_at       DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_comp_participant (competition_id, user_id),
    INDEX idx_comp_participants_user_id        (user_id),
    INDEX idx_comp_participants_status         (competition_id, status),
    CONSTRAINT fk_comp_participants_competition
        FOREIGN KEY (competition_id) REFERENCES competitions (id),
    CONSTRAINT fk_comp_participants_user
        FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 5. gameweeks
-- ---------------------------------------------------------------------------
CREATE TABLE gameweeks (
    id              BIGINT   NOT NULL AUTO_INCREMENT,
    competition_id  BIGINT   NOT NULL,
    week_number     INT      NOT NULL,
    lock_at         DATETIME NOT NULL,
    starts_at       DATETIME NOT NULL,
    ends_at         DATETIME NOT NULL,
    status          ENUM('UPCOMING', 'LOCKED', 'IN_PROGRESS', 'COMPLETED') NOT NULL DEFAULT 'UPCOMING',
    PRIMARY KEY (id),
    UNIQUE KEY uk_gameweek (competition_id, week_number),
    INDEX idx_gameweeks_status (status),
    CONSTRAINT fk_gameweeks_competition
        FOREIGN KEY (competition_id) REFERENCES competitions (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 6. fixtures
-- ---------------------------------------------------------------------------
CREATE TABLE fixtures (
    id                     BIGINT       NOT NULL AUTO_INCREMENT,
    gameweek_id            BIGINT       NOT NULL,
    external_fixture_id    VARCHAR(100) NULL,

    -- Imported data (from external API)
    imported_home_team_id  BIGINT       NULL,
    imported_away_team_id  BIGINT       NULL,
    imported_kickoff_at    DATETIME     NULL,
    imported_status        ENUM('SCHEDULED', 'IN_PLAY', 'FINISHED', 'POSTPONED', 'CANCELLED') NOT NULL DEFAULT 'SCHEDULED',
    imported_score_home    INT          NULL,
    imported_score_away    INT          NULL,

    -- Admin overrides (take precedence when non-NULL)
    override_home_team_id  BIGINT       NULL,
    override_away_team_id  BIGINT       NULL,
    override_kickoff_at    DATETIME     NULL,
    override_status        ENUM('SCHEDULED', 'IN_PLAY', 'FINISHED', 'POSTPONED', 'CANCELLED') NULL,
    override_score_home    INT          NULL,
    override_score_away    INT          NULL,

    last_synced_at         DATETIME     NULL,
    created_at             DATETIME     NOT NULL,
    updated_at             DATETIME     NULL,

    PRIMARY KEY (id),
    INDEX idx_fixtures_gameweek_id          (gameweek_id),
    INDEX idx_fixtures_external_fixture_id  (external_fixture_id),
    INDEX idx_fixtures_imported_home_team   (imported_home_team_id),
    INDEX idx_fixtures_imported_away_team   (imported_away_team_id),
    INDEX idx_fixtures_override_home_team   (override_home_team_id),
    INDEX idx_fixtures_override_away_team   (override_away_team_id),
    INDEX idx_fixtures_imported_status      (imported_status),
    CONSTRAINT fk_fixtures_gameweek
        FOREIGN KEY (gameweek_id) REFERENCES gameweeks (id),
    CONSTRAINT fk_fixtures_imported_home_team
        FOREIGN KEY (imported_home_team_id) REFERENCES teams (id),
    CONSTRAINT fk_fixtures_imported_away_team
        FOREIGN KEY (imported_away_team_id) REFERENCES teams (id),
    CONSTRAINT fk_fixtures_override_home_team
        FOREIGN KEY (override_home_team_id) REFERENCES teams (id),
    CONSTRAINT fk_fixtures_override_away_team
        FOREIGN KEY (override_away_team_id) REFERENCES teams (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 7. picks
-- ---------------------------------------------------------------------------
CREATE TABLE picks (
    id              BIGINT   NOT NULL AUTO_INCREMENT,
    competition_id  BIGINT   NOT NULL,
    user_id         BIGINT   NOT NULL,
    gameweek_id     BIGINT   NOT NULL,
    team_id         BIGINT   NOT NULL,
    picked_at       DATETIME NOT NULL,
    source          ENUM('USER', 'AUTO') NOT NULL DEFAULT 'USER',
    locked          BOOLEAN  NOT NULL DEFAULT FALSE,
    PRIMARY KEY (id),
    UNIQUE KEY uk_pick_per_week (competition_id, user_id, gameweek_id),
    UNIQUE KEY uk_pick_team_once (competition_id, user_id, team_id),
    INDEX idx_picks_user_id     (user_id),
    INDEX idx_picks_gameweek_id (gameweek_id),
    INDEX idx_picks_team_id     (team_id),
    CONSTRAINT fk_picks_competition
        FOREIGN KEY (competition_id) REFERENCES competitions (id),
    CONSTRAINT fk_picks_user
        FOREIGN KEY (user_id) REFERENCES users (id),
    CONSTRAINT fk_picks_gameweek
        FOREIGN KEY (gameweek_id) REFERENCES gameweeks (id),
    CONSTRAINT fk_picks_team
        FOREIGN KEY (team_id) REFERENCES teams (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 8. pick_results
-- ---------------------------------------------------------------------------
CREATE TABLE pick_results (
    id          BIGINT   NOT NULL AUTO_INCREMENT,
    pick_id     BIGINT   NOT NULL,
    outcome     ENUM('PENDING', 'ADVANCE', 'ELIMINATED', 'POSTPONED_ADVANCE') NOT NULL DEFAULT 'PENDING',
    resolved_at DATETIME NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_pick_results_pick_id (pick_id),
    CONSTRAINT fk_pick_results_pick
        FOREIGN KEY (pick_id) REFERENCES picks (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
-- 9. audit_logs
-- ---------------------------------------------------------------------------
CREATE TABLE audit_logs (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    user_id     BIGINT       NULL,
    entity_type VARCHAR(50)  NOT NULL,
    entity_id   BIGINT       NOT NULL,
    field_name  VARCHAR(100) NULL,
    old_value   TEXT         NULL,
    new_value   TEXT         NULL,
    action      VARCHAR(50)  NOT NULL,
    created_at  DATETIME     NOT NULL,
    PRIMARY KEY (id),
    INDEX idx_audit_logs_user_id     (user_id),
    INDEX idx_audit_logs_entity      (entity_type, entity_id),
    INDEX idx_audit_logs_action      (action),
    INDEX idx_audit_logs_created_at  (created_at),
    CONSTRAINT fk_audit_logs_user
        FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
